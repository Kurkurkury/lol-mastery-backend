// server.js – Mock + Live (Riot) per .env schaltbar
// MOCK_MODE=true  -> nur Mock-Daten für Mastery
// MOCK_MODE=false -> echte Riot-API

const dotenv = require("dotenv");
dotenv.config({ override: true });

console.log("RIOT_API_KEY aus .env:", process.env.RIOT_API_KEY);

const express = require("express");
const cors = require("cors");
const fs = require("fs");
const path = require("path");
const fetch = require("cross-fetch");

const app = express();

// Wichtig für Hosting: Port vom Hoster verwenden, sonst 4000
const PORT = process.env.PORT || 4000;

const USE_MOCK = process.env.MOCK_MODE === "true";
const RIOT_API_KEY = process.env.RIOT_API_KEY || null;

// *** Faktor: Stunden pro Account-Level (Spielzeit-Schätzung) ***
const HOURS_PER_LEVEL = 7.5;

console.log("MOCK_MODE:", USE_MOCK ? "true (Mock aktiv)" : "false (Riot-Live)");

if (!USE_MOCK) {
  if (!RIOT_API_KEY) {
    console.warn(
      "⚠ WARNUNG: MOCK_MODE=false, aber kein RIOT_API_KEY in .env gesetzt."
    );
  } else {
    console.log("✔ Riot-Live-Modus mit API-Key aktiv");
  }
}

// ---------------------------------------------------------
// Mock-Daten, falls MOCK_MODE=true (nur für Mastery)
// ---------------------------------------------------------
let mockMastery = null;
if (USE_MOCK) {
  const mockPath = path.join(__dirname, "data", "mock-mastery.json");
  try {
    const raw = fs.readFileSync(mockPath, "utf8");
    mockMastery = JSON.parse(raw);
    console.log("✔ mock-mastery.json geladen");
  } catch (err) {
    console.error("❌ Konnte mock-mastery.json nicht laden:", err.message);
    process.exit(1);
  }
}

// ---------------------------------------------------------
// Hilfsfunktionen – Riot API Queue + Parsing
// ---------------------------------------------------------

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// Promise-Queue für Riot-Requests (werden sequentiell abgearbeitet)
let riotQueue = Promise.resolve();

// Mindestabstand zwischen zwei Riot-Requests (in ms).
// 2500 ms ≈ 1 Request alle 2.5 Sekunden (~48 Requests pro 2 Minuten)
const RIOT_MIN_DELAY_MS = 2500;

async function riotGetJson(url) {
  if (!RIOT_API_KEY) {
    throw new Error("Kein RIOT_API_KEY gesetzt");
  }

  const runInQueue = async () => {
    let attempt = 1;

    while (true) {
      const start = Date.now();

      const res = await fetch(url, {
        headers: {
          "X-Riot-Token": RIOT_API_KEY,
        },
      });

      const elapsed = Date.now() - start;
      if (elapsed < RIOT_MIN_DELAY_MS) {
        await sleep(RIOT_MIN_DELAY_MS - elapsed);
      }

      // Rate-Limit: 429 Too Many Requests
      if (res.status === 429 && attempt <= 3) {
        const retryAfterHeader = res.headers.get("Retry-After");
        let retryMs = 1500;
        if (retryAfterHeader) {
          const parsed = parseFloat(retryAfterHeader);
          if (!Number.isNaN(parsed) && parsed > 0) {
            retryMs = parsed * 1000;
          }
        }
        console.warn(
          `[riotGetJson] 429 Rate Limit für URL: ${url} – Retry in ${retryMs}ms (Versuch ${attempt})`
        );
        attempt += 1;
        await sleep(retryMs);
        continue;
      }

      if (!res.ok) {
        const text = await res.text();
        throw new Error(`Riot API Fehler ${res.status}: ${text}`);
      }

      return res.json();
    }
  };

  const next = riotQueue.then(runInQueue);
  riotQueue = next.catch(() => {});
  return next;
}

// Riot-ID "Name#TAG" in { name, tagline }
function parseRiotId(str) {
  const idx = str.lastIndexOf("#");
  if (idx === -1) {
    return { name: str, tagline: "EUW" };
  }
  const name = str.slice(0, idx);
  const tagline = str.slice(idx + 1);
  return { name, tagline };
}

// EU-Cluster (für EUW/EUNE)
async function getPUUIDFromRiotId(name, tagline) {
  const base = "https://europe.api.riotgames.com";
  const url = `${base}/riot/account/v1/accounts/by-riot-id/${encodeURIComponent(
    name
  )}/${encodeURIComponent(tagline)}`;
  return riotGetJson(url);
}

// Plattform-URL pro Region (für Summoner/Mastery)
function getPlatformBaseUrl(region) {
  return `https://${region}.api.riotgames.com`;
}

// Summoner-Daten inkl. Level für Spielzeit-Schätzung
async function getSummonerByPUUID(puuid, region) {
  const base = getPlatformBaseUrl(region);
  const url = `${base}/lol/summoner/v4/summoners/by-puuid/${encodeURIComponent(
    puuid
  )}`;
  return riotGetJson(url);
}

// Alle Champion-Masteries eines Summoners (für Gesamt-Mastery/OPUS)
async function getAllMasteriesByPUUID(puuid, region) {
  const base = getPlatformBaseUrl(region);
  const url = `${base}/lol/champion-mastery/v4/champion-masteries/by-puuid/${encodeURIComponent(
    puuid
  )}`;
  return riotGetJson(url);
}

// ---------------------------------------------------------
// Hintergrund-Jobs für Playtime (nur Level-basierte Schätzung)
// ---------------------------------------------------------

const JOBS_FILE = path.join(__dirname, "data", "playtime_jobs.json");
let playtimeJobs = {};

// Jobs von Disk laden (best effort)
(function loadJobsFromDisk() {
  try {
    if (fs.existsSync(JOBS_FILE)) {
      const raw = fs.readFileSync(JOBS_FILE, "utf8");
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed === "object") {
        playtimeJobs = parsed;
        console.log(
          `✔ Playtime-Jobs von Disk geladen (${Object.keys(playtimeJobs).length} Jobs)`
        );
      }
    }
  } catch (err) {
    console.warn("⚠ Konnte Playtime-Jobs nicht laden:", err.message);
  }
})();

function saveJobsToDisk() {
  try {
    const dir = path.dirname(JOBS_FILE);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(JOBS_FILE, JSON.stringify(playtimeJobs, null, 2), "utf8");
  } catch (err) {
    console.warn("⚠ Konnte Playtime-Jobs nicht speichern:", err.message);
  }
}

function createPlaytimeJob(accounts) {
  const id =
    Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 8);

  const now = new Date().toISOString();

  const job = {
    id,
    status: "pending", // pending | running | done | error
    totalAccounts: accounts.length,
    processedAccounts: 0,
    totalMatches: 0, // bleibt 0, da wir keine Matches mehr zählen
    totalHours: 0,
    accounts: accounts.map((acc) => ({
      name: acc.name,
      region: acc.region,
      matches: 0, // nur der Vollständigkeit halber
      hours: 0,
      totalGames: 0,
      estimatedHours: 0,
      estimationSource: null,
      level: null,
      error: null,
    })),
    error: null,
    createdAt: now,
    updatedAt: now,
  };

  playtimeJobs[id] = job;
  saveJobsToDisk();

  // Job im Hintergrund starten
  runPlaytimeJob(job).catch((err) => {
    console.error("[runPlaytimeJob] unerwarteter Fehler:", err.message);
    job.status = "error";
    job.error = err.message;
    job.updatedAt = new Date().toISOString();
    saveJobsToDisk();
  });

  return job;
}

async function runPlaytimeJob(job) {
  if (!job || job.status !== "pending") return;

  console.log(
    `[runPlaytimeJob] Starte Playtime-Job ${job.id} mit ${job.totalAccounts} Accounts`
  );

  job.status = "running";
  job.updatedAt = new Date().toISOString();
  saveJobsToDisk();

  let totalHours = 0;

  for (let i = 0; i < job.accounts.length; i++) {
    const accJob = job.accounts[i];

    try {
      const { name, tagline } = parseRiotId(accJob.name);
      const accountData = await getPUUIDFromRiotId(name, tagline);
      const puuid = accountData.puuid;

      const summoner = await getSummonerByPUUID(puuid, accJob.region);
      const level = summoner.summonerLevel || 0;

      const hours = level * HOURS_PER_LEVEL;

      accJob.matches = 0;
      accJob.hours = hours;
      accJob.totalGames = 0;
      accJob.estimatedHours = hours;
      accJob.level = level;
      accJob.estimationSource = "level_based";
      accJob.error = null;

      totalHours += hours;
    } catch (err) {
      console.error(
        `[runPlaytimeJob] Fehler bei Account ${accJob.name}:`,
        err.message
      );
      accJob.matches = 0;
      accJob.hours = 0;
      accJob.totalGames = 0;
      accJob.estimatedHours = 0;
      accJob.level = null;
      accJob.estimationSource = null;
      accJob.error = err.message;
    }

    job.processedAccounts = i + 1;
    job.updatedAt = new Date().toISOString();
    saveJobsToDisk();
  }

  job.totalMatches = 0; // wir zählen keine Matches mehr
  job.totalHours = totalHours;
  job.status = "done";
  job.updatedAt = new Date().toISOString();
  saveJobsToDisk();

  console.log(
    `[runPlaytimeJob] Job ${job.id} fertig: ~${job.totalHours.toFixed(
      1
    )} Stunden (Level-basiert)`
  );
}

// ---------------------------------------------------------
// Express Middleware
// ---------------------------------------------------------

app.use(cors());
app.use(express.json());

// ---------------------------------------------------------
// API-Routen
// ---------------------------------------------------------

// Health-Check
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", mode: USE_MOCK ? "mock" : "live" });
});

// Account-Lookup: Riot-ID -> PUUID & Region zurückgeben
// Frontend ruft: /api/account?riotId=Name#TAG&region=euw1
app.get("/api/account", async (req, res) => {
  try {
    const riotId = req.query.riotId;
    const region = req.query.region || "euw1";

    if (!riotId) {
      return res.status(400).json({ error: "riotId ist erforderlich" });
    }

    const { name, tagline } = parseRiotId(riotId);
    const data = await getPUUIDFromRiotId(name, tagline);

    res.json({
      gameName: data.gameName,
      tagLine: data.tagLine,
      puuid: data.puuid,
      region,
    });
  } catch (err) {
    console.error("[/api/account] Fehler:", err.message);
    res.status(500).json({ error: err.message });
  }
});

/**
 * POST /api/mastery/overall
 * Request: { accounts: [{ name, region }, ...] }
 * Antwort: { totalPoints, accounts: [{ name, region, points, level }, ...] }
 */
app.post("/api/mastery/overall", async (req, res) => {
  try {
    const accounts = req.body.accounts;
    if (!Array.isArray(accounts) || accounts.length === 0) {
      return res
        .status(400)
        .json({ error: "accounts-Array wird benötigt (name, region)" });
    }

    if (USE_MOCK) {
      let totalPoints = 0;
      const resultAccounts = [];

      for (const acc of accounts) {
        const points = mockMastery
          .filter((m) => m.account === acc.name)
          .reduce((sum, m) => sum + m.points, 0);
        totalPoints += points;
        resultAccounts.push({
          name: acc.name,
          region: acc.region,
          points,
          level: 0,
        });
      }

      return res.json({ totalPoints, accounts: resultAccounts });
    }

    let totalPoints = 0;
    const resultAccounts = [];

    for (const acc of accounts) {
      try {
        const { name, tagline } = parseRiotId(acc.name);
        const accountData = await getPUUIDFromRiotId(name, tagline);
        const puuid = accountData.puuid;

        const masteries = await getAllMasteriesByPUUID(puuid, acc.region);
        const sumPoints = masteries.reduce(
          (sum, m) => sum + (m.championPoints || 0),
          0
        );

        totalPoints += sumPoints;

        resultAccounts.push({
          name: acc.name,
          region: acc.region,
          points: sumPoints,
          level: 0,
        });
      } catch (innerErr) {
        console.error(
          `[/api/mastery/overall] Fehler bei Account ${acc.name}:`,
          innerErr.message
        );
        resultAccounts.push({
          name: acc.name,
          region: acc.region,
          points: 0,
          level: 0,
          error: innerErr.message,
        });
      }
    }

    res.json({ totalPoints, accounts: resultAccounts });
  } catch (err) {
    console.error("[/api/mastery/overall] Fehler:", err.message);
    res.status(500).json({
      error: "Interner Fehler bei /api/mastery/overall: " + err.message,
    });
  }
});

/**
 * POST /api/mastery/champion
 * Request: { championId, championName, accounts: [{ name, region }, ...] }
 */
app.post("/api/mastery/champion", async (req, res) => {
  try {
    const { championId, championName, accounts } = req.body;

    if (!championId || !Array.isArray(accounts) || accounts.length === 0) {
      return res.status(400).json({
        error:
          "championId und accounts-Array (name, region) sind erforderlich",
      });
    }

    if (USE_MOCK) {
      let totalPoints = 0;
      const resultAccounts = [];

      for (const acc of accounts) {
        const entry = mockMastery.find(
          (m) => m.account === acc.name && m.championId === championId
        );
        const points = entry ? entry.points : 0;
        const level = entry ? entry.level : 0;

        totalPoints += points;
        resultAccounts.push({
          name: acc.name,
          region: acc.region,
          points,
          level,
        });
      }

      return res.json({
        championId,
        championName: championName || null,
        totalPoints,
        accounts: resultAccounts,
      });
    }

    const resultAccounts = [];

    for (const acc of accounts) {
      try {
        const { name, tagline } = parseRiotId(acc.name);
        const accountData = await getPUUIDFromRiotId(name, tagline);
        const puuid = accountData.puuid;

        const base = getPlatformBaseUrl(acc.region);
        const url = `${base}/lol/champion-mastery/v4/champion-masteries/by-puuid/${encodeURIComponent(
          puuid
        )}/by-champion/${encodeURIComponent(championId)}`;

        let points = 0;
        let level = 0;

        try {
          const champData = await riotGetJson(url);
          points = champData.championPoints || 0;
          level = champData.championLevel || 0;
        } catch (err) {
          console.warn(
            `[/api/mastery/champion] Kein Mastery-Eintrag für ${acc.name} (Champion ${championId}):`,
            err.message
          );
        }

        resultAccounts.push({
          name: acc.name,
          region: acc.region,
          points,
          level,
        });
      } catch (innerErr) {
        console.error(
          `[/api/mastery/champion] Fehler bei Account ${acc.name}:`,
          innerErr.message
        );
        resultAccounts.push({
          name: acc.name,
          region: acc.region,
          points: 0,
          level: 0,
          error: innerErr.message,
        });
      }
    }

    const totalPoints = resultAccounts.reduce(
      (sum, r) => sum + (r.points || 0),
      0
    );

    res.json({
      championId,
      championName: championName || null,
      totalPoints,
      accounts: resultAccounts,
    });
  } catch (err) {
    console.error("[/api/mastery/champion] Fehler:", err.message);
    res.status(500).json({
      error: "Interner Fehler bei /api/mastery/champion: " + err.message,
    });
  }
});

/**
 * Synchrone Variante für Spielzeit (Level-basiert)
 * POST /api/playtime/profile
 */
app.post("/api/playtime/profile", async (req, res) => {
  try {
    const accounts = req.body.accounts;
    if (!Array.isArray(accounts) || accounts.length === 0) {
      return res
        .status(400)
        .json({ error: "accounts-Array wird benötigt (name, region)" });
    }

    const resultAccounts = [];
    let totalHours = 0;

    for (const acc of accounts) {
      try {
        const { name, tagline } = parseRiotId(acc.name);
        const accountData = await getPUUIDFromRiotId(name, tagline);
        const puuid = accountData.puuid;

        const summoner = await getSummonerByPUUID(puuid, acc.region);
        const level = summoner.summonerLevel || 0;
        const hours = level * HOURS_PER_LEVEL;

        totalHours += hours;

        resultAccounts.push({
          name: acc.name,
          region: acc.region,
          matches: 0,
          hours,
          totalGames: 0,
          estimatedHours: hours,
          level,
          estimationSource: "level_based",
        });
      } catch (innerErr) {
        console.error(
          `[/api/playtime/profile] Fehler bei Account ${acc.name}:`,
          innerErr.message
        );
        resultAccounts.push({
          name: acc.name,
          region: acc.region,
          matches: 0,
          hours: 0,
          totalGames: 0,
          estimatedHours: 0,
          level: null,
          estimationSource: null,
          error: innerErr.message,
        });
      }
    }

    return res.json({
      totalMatches: 0,
      totalHours,
      accounts: resultAccounts,
    });
  } catch (err) {
    console.error("[/api/playtime/profile] Fehler:", err.message);
    return res.status(500).json({
      error: "Interner Fehler bei /api/playtime/profile: " + err.message,
    });
  }
});

// ---------- Hintergrund-Job-API für Playtime ----------

/**
 * POST /api/playtime/profile/start
 * Request: { accounts: [{ name, region }, ...] }
 */
app.post("/api/playtime/profile/start", (req, res) => {
  try {
    const accounts = req.body.accounts;
    if (!Array.isArray(accounts) || accounts.length === 0) {
      return res
        .status(400)
        .json({ error: "accounts-Array wird benötigt (name, region)" });
    }

    const job = createPlaytimeJob(accounts);
    res.json({
      jobId: job.id,
      totalAccounts: job.totalAccounts,
      status: job.status,
      createdAt: job.createdAt,
    });
  } catch (err) {
    console.error("[/api/playtime/profile/start] Fehler:", err.message);
    res.status(500).json({
      error: "Interner Fehler bei /api/playtime/profile/start: " + err.message,
    });
  }
});

/**
 * GET /api/playtime/profile/status?jobId=...
 */
app.get("/api/playtime/profile/status", (req, res) => {
  try {
    const jobId = req.query.jobId;
    if (!jobId) {
      return res.status(400).json({ error: "jobId ist erforderlich" });
    }

    const job = playtimeJobs[jobId];
    if (!job) {
      return res.status(404).json({ error: "Job nicht gefunden" });
    }

    res.json({
      jobId: job.id,
      status: job.status,
      processedAccounts: job.processedAccounts,
      totalAccounts: job.totalAccounts,
      error: job.error,
      createdAt: job.createdAt,
      updatedAt: job.updatedAt,
    });
  } catch (err) {
    console.error("[/api/playtime/profile/status] Fehler:", err.message);
    res.status(500).json({
      error: "Interner Fehler bei /api/playtime/profile/status: " + err.message,
    });
  }
});

/**
 * GET /api/playtime/profile/result?jobId=...
 * - Wenn Job fertig: 200 + Ergebnis
 * - Wenn noch nicht fertig: 202 + Status
 */
app.get("/api/playtime/profile/result", (req, res) => {
  try {
    const jobId = req.query.jobId;
    if (!jobId) {
      return res.status(400).json({ error: "jobId ist erforderlich" });
    }

    const job = playtimeJobs[jobId];
    if (!job) {
      return res.status(404).json({ error: "Job nicht gefunden" });
    }

    if (job.status !== "done") {
      return res.status(202).json({
        jobId: job.id,
        status: job.status,
        processedAccounts: job.processedAccounts,
        totalAccounts: job.totalAccounts,
        error: job.error,
        createdAt: job.createdAt,
        updatedAt: job.updatedAt,
      });
    }

    return res.json({
      jobId: job.id,
      status: job.status,
      totalMatches: job.totalMatches, // bleibt 0
      totalHours: job.totalHours,
      accounts: job.accounts,
      createdAt: job.createdAt,
      updatedAt: job.updatedAt,
    });
  } catch (err) {
    console.error("[/api/playtime/profile/result] Fehler:", err.message);
    res.status(500).json({
      error: "Interner Fehler bei /api/playtime/profile/result: " + err.message,
    });
  }
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`✔ Server läuft auf Port ${PORT}`);
});
