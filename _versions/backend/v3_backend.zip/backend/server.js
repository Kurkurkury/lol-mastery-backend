// server.js – Mock + Live (Riot) per .env schaltbar
// MOCK_MODE=true  -> nur Mock-Daten
// MOCK_MODE=false -> echte Riot-API

const dotenv = require("dotenv");
dotenv.config({ override: true });

console.log("RIOT_API_KEY aus .env:", process.env.RIOT_API_KEY);

const axios = require("axios"); // aktuell nicht genutzt, kann aber bleiben
const express = require("express");
const cors = require("cors");
const fs = require("fs");
const path = require("path");
const fetch = require("cross-fetch");

const app = express();

// Wichtig für Hosting: Port vom Hoster verwenden, sonst 4000
const PORT = process.env.PORT || 4000;

const USE_MOCK = process.env.MOCK_MODE === "true";
const RIOT_API_KEY = process.env.RIOT_API_KEY || null;

// *** neuer Faktor: Stunden pro Account-Level ***
const HOURS_PER_LEVEL = 7.5;

console.log("MOCK_MODE:", USE_MOCK ? "true (Mock aktiv)" : "false (Riot-Live)");

if (!USE_MOCK) {
  if (!RIOT_API_KEY) {
    console.warn(
      "⚠ WARNUNG: MOCK_MODE=false, aber kein RIOT_API_KEY in .env gesetzt."
    );
  } else {
    console.log("✔ Riot-Live-Modus mit API-Key aktiv");
  }
}

// Mock-Daten, falls MOCK_MODE=true
let mockMastery = null;
if (USE_MOCK) {
  const mockPath = path.join(__dirname, "data", "mock-mastery.json");
  try {
    const raw = fs.readFileSync(mockPath, "utf8");
    mockMastery = JSON.parse(raw);
    console.log("✔ mock-mastery.json geladen");
  } catch (err) {
    console.error("❌ Konnte mock-mastery.json nicht laden:", err.message);
    process.exit(1);
  }
}

// ---------- Hilfsfunktionen ----------

// --- Riot API Call mit einfachem Rate-Limit & Retry bei 429 ---
// Variante A: maximale Sicherheit, möglichst wenig Rate-Limit-Fehler.
// Alle Requests laufen seriell, mit mindestens 1 Sekunde Abstand.

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// Promise-Queue für Riot-Requests (wird sequentiell abgearbeitet)
let riotQueue = Promise.resolve();

// Mindestabstand zwischen zwei Riot-Requests (in ms).
// 1000 ms = 1 Request pro Sekunde (sehr konservativ, wenige Fehler, aber langsam).
const RIOT_MIN_DELAY_MS = 1000;

async function riotGetJson(url) {
  // Wir hängen jeden Request an die Queue an, damit sie nacheinander laufen.
  const runInQueue = async () => {
    let attempt = 1;

    while (true) {
      const start = Date.now();

      const res = await fetch(url, {
        headers: {
          "X-Riot-Token": RIOT_API_KEY,
        },
      });

      const elapsed = Date.now() - start;
      // kleine Pause bis zum nächsten Request, falls der Call sehr schnell war
      if (elapsed < RIOT_MIN_DELAY_MS) {
        await sleep(RIOT_MIN_DELAY_MS - elapsed);
      }

      // Rate-Limit: 429 Too Many Requests
      if (res.status === 429 && attempt <= 3) {
        const retryAfterHeader = res.headers.get("Retry-After");
        let retryMs = 1500;
        if (retryAfterHeader) {
          const parsed = parseFloat(retryAfterHeader);
          if (!Number.isNaN(parsed) && parsed > 0) {
            retryMs = parsed * 1000;
          }
        }
        console.warn(
          `[riotGetJson] 429 Rate Limit für URL: ${url} – Retry in ${retryMs}ms (Versuch ${attempt})`
        );
        attempt += 1;
        await sleep(retryMs);
        continue; // nächster Versuch
      }

      if (!res.ok) {
        const text = await res.text();
        throw new Error(`Riot API Fehler ${res.status}: ${text}`);
      }

      return res.json();
    }
  };

  // neuen Job an die Queue hängen
  const next = riotQueue.then(runInQueue);
  // Fehler in der Queue abfangen, damit die Kette nicht "bricht"
  riotQueue = next.catch(() => {});
  return next;
}

// Hilfs-Parser: Riot-ID "Name#TAG" in { name, tagline }
function parseRiotId(str) {
  const idx = str.lastIndexOf("#");
  if (idx === -1) {
    return { name: str, tagline: "EUW" };
  }
  const name = str.slice(0, idx);
  const tagline = str.slice(idx + 1);
  return { name, tagline };
}

// PUUID anhand Riot-ID holen
async function getPUUIDFromRiotId(name, tagline) {
  const base = "https://europe.api.riotgames.com";
  const url = `${base}/riot/account/v1/accounts/by-riot-id/${encodeURIComponent(
    name
  )}/${encodeURIComponent(tagline)}`;

  return riotGetJson(url);
}

// Regionale Plattform-URL für Champion-Mastery / Summoner
function getPlatformBaseUrl(region) {
  return `https://${region}.api.riotgames.com`;
}

// Match-V5 Routing-Cluster für Spielzeit
function getMatchCluster(region) {
  const r = region.toLowerCase();
  if (["euw1", "eun1", "tr1", "ru"].includes(r)) return "europe";
  if (["na1", "br1", "la1", "la2", "oc1"].includes(r)) return "americas";
  if (["kr", "jp1"].includes(r)) return "asia";
  if (["sg2", "ph2", "vn2", "th2", "tw2"].includes(r)) return "sea";
  // Fallback
  return "europe";
}

// Alle Champion-Masteries eines Summoners holen (für /api/mastery/overall und /api/mastery)
async function getAllMasteriesByPUUID(puuid, region) {
  const base = getPlatformBaseUrl(region);
  const url = `${base}/lol/champion-mastery/v4/champion-masteries/by-puuid/${encodeURIComponent(
    puuid
  )}`;
  return riotGetJson(url); // Array von Masteries
}

// Anzahl Matches für PUUID zählen (Match-V5)
async function getMatchCountForPUUID(puuid, region) {
  const cluster = getMatchCluster(region);
  const base = `https://${cluster}.api.riotgames.com`;

  let start = 0;
  const step = 100;
  let total = 0;

  while (true) {
    const url = `${base}/lol/match/v5/matches/by-puuid/${encodeURIComponent(
      puuid
    )}/ids?start=${start}&count=${step}`;
    const ids = await riotGetJson(url); // array von Match-IDs

    if (!Array.isArray(ids) || ids.length === 0) {
      break;
    }

    total += ids.length;
    if (ids.length < step) {
      break;
    }

    start += step;
  }

  return total;
}

// ---------- Express Middleware ----------

app.use(cors());
app.use(express.json());

// ---------- API-Routen ----------

// Health-Check
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", mode: USE_MOCK ? "mock" : "live" });
});

// Account-Lookup: Riot-ID -> PUUID & Region zurückgeben
app.get("/api/account", async (req, res) => {
  try {
    const riotId = req.query.riotId;
    const region = req.query.region || "euw1";

    if (!riotId) {
      return res.status(400).json({ error: "riotId ist erforderlich" });
    }

    const { name, tagline } = parseRiotId(riotId);
    const data = await getPUUIDFromRiotId(name, tagline);

    res.json({
      gameName: data.gameName,
      tagLine: data.tagLine,
      puuid: data.puuid,
      region,
    });
  } catch (err) {
    console.error("[/api/account] Fehler:", err.message);
    res.status(500).json({ error: err.message });
  }
});

/**
 * POST /api/mastery/overall
 * Request: { accounts: [{ name, region }, ...] }
 * Antwort: { totalPoints, accounts: [{ name, region, points, level }, ...] }
 *
 * Summiert alle Mastery-Punkte über alle Champions pro Account.
 */
app.post("/api/mastery/overall", async (req, res) => {
  try {
    const accounts = req.body.accounts;
    if (!Array.isArray(accounts) || accounts.length === 0) {
      return res
        .status(400)
        .json({ error: "accounts-Array wird benötigt (name, region)" });
    }

    if (USE_MOCK) {
      // Mock verhalten: Summiere einfach alles aus mockMastery für jeden Account
      let totalPoints = 0;
      const resultAccounts = [];

      for (const acc of accounts) {
        const points = mockMastery
          .filter((m) => m.account === acc.name)
          .reduce((sum, m) => sum + m.points, 0);
        totalPoints += points;
        resultAccounts.push({
          name: acc.name,
          region: acc.region,
          points,
          level: 0,
        });
      }

      return res.json({ totalPoints, accounts: resultAccounts });
    }

    // Live-Modus: echte Riot-API
    let totalPoints = 0;
    const resultAccounts = [];

    for (const acc of accounts) {
      try {
        const { name, tagline } = parseRiotId(acc.name);
        const accountData = await getPUUIDFromRiotId(name, tagline);
        const puuid = accountData.puuid;

        const masteries = await getAllMasteriesByPUUID(puuid, acc.region);
        const sumPoints = masteries.reduce(
          (sum, m) => sum + (m.championPoints || 0),
          0
        );

        totalPoints += sumPoints;

        resultAccounts.push({
          name: acc.name,
          region: acc.region,
          points: sumPoints,
          level: 0,
        });
      } catch (innerErr) {
        console.error(
          `[/api/mastery/overall] Fehler bei Account ${acc.name}:`,
          innerErr.message
        );
        resultAccounts.push({
          name: acc.name,
          region: acc.region,
          points: 0,
          level: 0,
          error: innerErr.message,
        });
      }
    }

    res.json({ totalPoints, accounts: resultAccounts });
  } catch (err) {
    console.error("[/api/mastery/overall] Fehler:", err.message);
    res
      .status(500)
      .json({ error: "Interner Fehler bei /api/mastery/overall: " + err.message });
  }
});

/**
 * POST /api/mastery/champion
 * Request: { championId, championName, accounts: [{ name, region }, ...] }
 * Antwort:
 * {
 *   championId,
 *   championName,
 *   totalPoints,
 *   accounts: [
 *     { name, region, points, level }
 *   ]
 * }
 */
app.post("/api/mastery/champion", async (req, res) => {
  try {
    const { championId, championName, accounts } = req.body;

    if (!championId || !Array.isArray(accounts) || accounts.length === 0) {
      return res.status(400).json({
        error:
          "championId und accounts-Array (name, region) sind erforderlich",
      });
    }

    if (USE_MOCK) {
      // Mock-Modus: Filter aus mockMastery
      let totalPoints = 0;
      const resultAccounts = [];

      for (const acc of accounts) {
        const entry = mockMastery.find(
          (m) => m.account === acc.name && m.championId === championId
        );
        const points = entry ? entry.points : 0;
        const level = entry ? entry.level : 0;

        totalPoints += points;
        resultAccounts.push({
          name: acc.name,
          region: acc.region,
          points,
          level,
        });
      }

      return res.json({
        championId,
        championName: championName || null,
        totalPoints,
        accounts: resultAccounts,
      });
    }

    // Live-Modus
    const resultAccounts = [];

    for (const acc of accounts) {
      try {
        const { name, tagline } = parseRiotId(acc.name);
        const accountData = await getPUUIDFromRiotId(name, tagline);
        const puuid = accountData.puuid;

        const base = getPlatformBaseUrl(acc.region);
        const url = `${base}/lol/champion-mastery/v4/champion-masteries/by-puuid/${encodeURIComponent(
          puuid
        )}/by-champion/${encodeURIComponent(championId)}`;

        let points = 0;
        let level = 0;

        try {
          const champData = await riotGetJson(url);
          points = champData.championPoints || 0;
          level = champData.championLevel || 0;
        } catch (err) {
          console.warn(
            `[/api/mastery/champion] Kein Mastery-Eintrag für ${acc.name} (Champion ${championId}):`,
            err.message
          );
        }

        resultAccounts.push({
          name: acc.name,
          region: acc.region,
          points,
          level,
        });
      } catch (innerErr) {
        console.error(
          `[/api/mastery/champion] Fehler bei Account ${acc.name}:`,
          innerErr.message
        );
        resultAccounts.push({
          name: acc.name,
          region: acc.region,
          points: 0,
          level: 0,
          error: innerErr.message,
        });
      }
    }

    const totalPoints = resultAccounts.reduce(
      (sum, r) => sum + (r.points || 0),
      0
    );

    res.json({
      championId,
      championName: championName || null,
      totalPoints,
      accounts: resultAccounts,
    });
  } catch (err) {
    console.error("[/api/mastery/champion] Fehler:", err.message);
    res.status(500).json({
      error: "Interner Fehler bei /api/mastery/champion: " + err.message,
    });
  }
});

/**
 * POST /api/playtime/profile
 * Request: { accounts: [{ name, region }, ...] }
 * Antwort:
 * {
 *   totalMatches,
 *   totalHours,
 *   accounts: [
 *     { name, region, matches, hours }
 *   ]
 * }
 */
app.post("/api/playtime/profile", async (req, res) => {
  try {
    const accounts = req.body.accounts;
    if (!Array.isArray(accounts) || accounts.length === 0) {
      return res
        .status(400)
        .json({ error: "accounts-Array wird benötigt (name, region)" });
    }

    const resultAccounts = [];
    let totalMatches = 0;

    for (const acc of accounts) {
      try {
        const { name, tagline } = parseRiotId(acc.name);
        const accountData = await getPUUIDFromRiotId(name, tagline);
        const puuid = accountData.puuid;

        const matches = await getMatchCountForPUUID(puuid, acc.region);
        const hours = matches * HOURS_PER_LEVEL;

        totalMatches += matches;

        resultAccounts.push({
          name: acc.name,
          region: acc.region,
          matches,
          hours,
        });
      } catch (innerErr) {
        console.error(
          `[/api/playtime/profile] Fehler bei Account ${acc.name}:`,
          innerErr.message
        );
        resultAccounts.push({
          name: acc.name,
          region: acc.region,
          matches: 0,
          hours: 0,
          error: innerErr.message,
        });
      }
    }

    const totalHours = totalMatches * HOURS_PER_LEVEL;

    return res.json({
      totalMatches,
      totalHours,
      accounts: resultAccounts,
    });
  } catch (err) {
    console.error("[/api/playtime/profile] Fehler:", err.message);
    return res.status(500).json({
      error: "Interner Fehler bei /api/playtime/profile: " + err.message,
    });
  }
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`✔ Server läuft auf Port ${PORT}`);
});
